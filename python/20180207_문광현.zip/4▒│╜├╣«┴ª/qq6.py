def _sum(number1, number2):
    return number1 + number2


print(_sum(3, 5))
