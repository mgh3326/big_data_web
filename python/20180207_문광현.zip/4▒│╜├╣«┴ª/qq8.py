def maxlist(my_list):
    return max(my_list)


math_score = [80, 50, 90, 75, 35]
print("최고 점수는 " + str(maxlist(math_score)) + "점 입니다")
