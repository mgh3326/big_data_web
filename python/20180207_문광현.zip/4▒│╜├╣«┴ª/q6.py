def dec_food(coin):
    if coin == '앞':
        print("중국 요리")
    elif coin == '뒷':
        print("일본 요리")
    else:
        print("동전의 앞 뒷 만 입력해주세요")


dec_food('앞')
