order = 1
alpabet = "abcde"
for alpabet in 'abcde':
    print("%d 번째 알파뱃은 " % order + alpabet)
    order += 1
