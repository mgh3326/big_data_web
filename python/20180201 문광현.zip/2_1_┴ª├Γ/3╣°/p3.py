score = int(input("현재 잔액을 입력해주세요 : "))
if score >= 1200:
    print("버스 탑승 가능합니다.")
else:
    print("버스 탑승 불가능합니다.")
