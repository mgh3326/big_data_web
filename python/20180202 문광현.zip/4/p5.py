fruit = ["strawberry", "apple", "banana", "watermelon", "grape"]

for i in reversed(fruit):
    print(i, end=", ")
