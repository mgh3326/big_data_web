stationery = {"연필": 200, "펜": 800, "지우개": 500, "자": 300}
stationery_value_list = list(stationery.values())
print(stationery_value_list)
