profit_percentage = 5
profit_money = 540

if profit_percentage >= 10 or profit_money > 500:
    print("주식 투자를 잘한 것이다.")
else:
    print("주식 투자를 잘 못한것이다..")
