def _round(width, height):
    return width * 2 + height * 2


print(_round(3, 6))
