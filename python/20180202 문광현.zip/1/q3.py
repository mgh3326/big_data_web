print(list(range(1, 20, 3)))
