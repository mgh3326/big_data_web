def maxlist(my_list):
    return max(my_list)


math_score = [80, 50, 90, 75, 35]
print(maxlist(math_score))
