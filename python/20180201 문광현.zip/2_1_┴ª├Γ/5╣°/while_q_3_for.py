for i in range(11, 17, 1):
    # print("-    %d 단    -" % i)
    for k in range(1, 10, 1):
        print("%3d" % (i * k), end=" ")
    print("")
    # print("")
