num = 5

while num > 0:
    for i in range(1, num + 1):
        print("*", end="")
    print("")
    num -= 1
