def tempo(n):
    print("증가 후의 음량는 %d 입니다." % (n + 3))


tempo(int(input("현재의 음량는 3입니다. \n증가시킬 만큼의 음량을 입력 : ")))
