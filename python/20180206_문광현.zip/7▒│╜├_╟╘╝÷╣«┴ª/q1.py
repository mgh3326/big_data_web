def revr(aa):
    aa.reverse()

    return aa


aa = [10, 20, 30]
print(revr(aa))
