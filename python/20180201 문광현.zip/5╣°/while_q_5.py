total = 0
for i in range(1, 101):
    if i % 2 == 0:
        total += i
print("0에서 100까지의 짝수의 합 : %d" % total)
