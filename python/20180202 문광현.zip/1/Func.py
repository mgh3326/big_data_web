def func1():
    print("Func.py의 func1()이 호출됨")


def func2():
    print("Func.py의 func2()이 호출됨")


def func3():
    print("Func.py의 func3()이 호출됨")
