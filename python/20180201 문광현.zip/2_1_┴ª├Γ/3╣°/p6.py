major = "computer science"
grade = 4

if major == "computer science" or grade == 4:
    print("문자가 온다.")
else:
    print("문자가 안 온다")
