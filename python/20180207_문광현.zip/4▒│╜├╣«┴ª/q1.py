def sub_number(number1, number2):
    return number1 - number2


print(2 - 1)
