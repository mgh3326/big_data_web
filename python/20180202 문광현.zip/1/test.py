import sys

# print(sys.path)
# sys.path.append("C:\p_temp\module")
# sys.path.insert(0, "C:\p_temp\module")
# import module2

# module2.hello()
print(sys.path)
