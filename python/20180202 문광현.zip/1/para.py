def dic_func(**para):
    for k in para.keys():
        print("%s --> %d  명입니다." % (k, para[k]))


dic_func(아이오아이=11, 소녀시대=8, 걸스데이=4, AOA=7)
