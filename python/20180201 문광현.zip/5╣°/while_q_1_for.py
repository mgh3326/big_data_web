for i in range(2, 5, 1):
    print("-    %d 단    -" % i)
    for k in range(1, 10, 1):
        print("%d X %d = %2d" % (i, k, i * k))
    # print("")
