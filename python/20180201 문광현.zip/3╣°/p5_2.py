score = 2
f_num=4
if score<=1 or f_num>=3:
    print("상민은 학사 경고를 받는다.")