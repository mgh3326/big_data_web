animal_list = ['dog', 'pig', 'tiger', 'eagle', 'cat', 'dog', 'pig', 'lion']
animal_set = set(animal_list)
new_animal_list = list(animal_set)
print(new_animal_list)