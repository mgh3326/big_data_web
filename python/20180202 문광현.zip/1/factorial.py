n = int(input("enter the number : "))
fact = 1
for i in range(1, n + 1):
    fact += i
print("%d != %d" % (n, fact))
