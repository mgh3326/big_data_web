def increase_3(num):
    return num + 3


n1 = 3
n2 = 4
n3 = 5
print(increase_3(n1))
print(increase_3(n2))
print(increase_3(n3))
