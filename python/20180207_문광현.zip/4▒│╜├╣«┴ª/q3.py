def concate_str(str1, str2):
    return str1 + str2


var1 = "안녕하세요"
var2 = "반갑습니다."
print(concate_str(var1, var2))
