food = {"돈가스": 5000, "생선가스": 5500, "우동": 2500, "초밥 세트": 9000}
food_list = list(food.items())
print(food_list)