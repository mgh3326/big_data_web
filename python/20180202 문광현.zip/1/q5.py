for spelling in 'Pyton':
    print(spelling + '*')
