def print_greeting(n):
    for count in range(n):
        return ('Hello, Python\n'*n)


print(print_greeting(3))