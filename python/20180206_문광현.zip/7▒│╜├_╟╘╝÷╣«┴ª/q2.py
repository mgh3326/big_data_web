strdata = 'Time is money!!'
print(strdata[1:5])
print(strdata[:])
print(strdata[::2])
