arr = (1, 2, 3)
brr = [arr[0], arr[2], arr[1]]
print(brr)