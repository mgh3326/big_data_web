def calc_monthly_salary(f_time, f_amount):
    return f_time * f_amount
