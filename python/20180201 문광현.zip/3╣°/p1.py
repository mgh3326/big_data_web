oil = int(input("현재 휘발유의 양을 입력해주세요 : "))
if oil < 10:
    print("휘발유 공급이 필요로 합니다.")
else:
    print("휘발유 공급이 필요로 하지 않습니다.")
