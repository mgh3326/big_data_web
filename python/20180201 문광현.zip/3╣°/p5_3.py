coin = input("동전의 앞 혹은 뒤를 입력해주세요 (앞/뒤)")
if coin == "앞":
    print("중국요리")
elif coin == "뒤":
    print("일본요리")
else:
    print("앞 뒷면을 올바르게 입력해주세요")
