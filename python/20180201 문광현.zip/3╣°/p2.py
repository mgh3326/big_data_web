score = int(input("이수한 학점을 입력해주세요 : "))
if score >= 140:
    print("졸업이 가능합니다.")
else:
    print("졸업이 불가능합니다.")
