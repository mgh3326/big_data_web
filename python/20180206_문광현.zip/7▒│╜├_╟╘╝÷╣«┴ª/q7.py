txt = 'aAbBcCdDeEfFgGhHiIjJkK'
ret = txt[::-1]
print(ret)
