num = int(input("숫자를 입력해주세요 : "))
if num % 3 == 0:
    print("3의 배수 입니다.")
else:
    print("3의 배수가 아닙니다.")