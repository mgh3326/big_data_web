height = 165
weight = 60
if height <= 155 and weight <= 50:
    print("입장 가능하다.")
else:
    print("입장 불가능하다.")
