num = 0
_sum = 0
while _sum <= 1000:
    num += 1
    _sum += num

print(num)
print(_sum)
