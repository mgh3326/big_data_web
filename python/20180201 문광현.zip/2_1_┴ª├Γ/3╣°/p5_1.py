total_price = 30000 + 50000 + 15000 + 25000
if total_price > 100000:
    print("상품권을 받을수 있습니다.")
