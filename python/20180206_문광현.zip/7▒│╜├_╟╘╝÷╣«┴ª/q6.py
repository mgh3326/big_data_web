txt = 'aAbBcCdDeEfFgGhHiIjJkK'
ret = txt[::2]
print(ret)
